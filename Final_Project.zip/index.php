<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="header">
	<h2>Home Page</h2>
</div>	
<div class="content">
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
	<form method="post" action=index.php">
    	<p>Welcome Student - Please select a Course to be added: <strong><?php echo $_SESSION['username']; ?></strong></p>
	<?php
	$mysqli = NEW mysqli('localhost','root','','db');

	$resultSet = $mysqli->query("SELECT course_name FROM course"); 
	?>

	<select name="course">
	<?php
	while($rows = $resultSet->fetch_assoc())
	{
		$course_name = $rows['course_name'];
		echo "<option value='$course_name'>$course_name</option>";
	}
	?>
	</select>
	<div class="input-group">
  	  	<button type="submit" class="btn" name="username">Submit</button>
  		</div>

    	<p> <a href="index.php?logout='1'" style="color: red;">1) Logout</a> </p>
	<p> <a href="remove.php?logout='1'" style="color: black;">2) Remove Courses</a> </p>
    <?php endif ?>
</div>
</form>
</body>
</html>